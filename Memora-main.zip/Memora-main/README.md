<<<<<<< HEAD
# memora

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
=======


# Memora 🎯


## Basic Details
### Team Name: Syntax Squad


### Team Members
- Member 1: Glenys Gladson - GEC thrissur
- Member 2: Dharshana K S - GEC thrissur
- Member 3: Christeena Geejo - GEC thrissur

### Hosted Project Link
[[mention your project hosted project link here]](https://github.com/GlenysGladson/Memora)

### Project Description
Helps users to efficiently revise topics via flashcards.

### The Problem statement
Difficulty to recall topics of complex structure.

### The Solution
Helps to actively recall key topics of the subject making learning and memorisation easier.

## Technical Details
### Technologies/Components Used
For Software:
- [Languages used]
- [Frameworks used]
- [Libraries used]
- [Tools used]

For Hardware:
- [List main components]
- [List specifications]
- [List tools required]

### Implementation
For Software:
# Installation
[commands]

# Run
[commands]

### Project Documentation
For Software:

# Screenshots (Add at least 3)
![Screenshot1](Add screenshot 1 here with proper name)
*Add caption explaining what this shows*

![Screenshot2](Add screenshot 2 here with proper name)
*Add caption explaining what this shows*

![Screenshot3](Add screenshot 3 here with proper name)
*Add caption explaining what this shows*

# Diagrams
![Workflow](Add your workflow/architecture diagram here)
*Add caption explaining your workflow*

For Hardware:

# Schematic & Circuit
![Circuit](Add your circuit diagram here)
*Add caption explaining connections*

![Schematic](Add your schematic diagram here)
https://drive.google.com/file/d/1WpuKBkQ6XEyL0JAijxxptRXd_3Xe-3qH/view?usp=drive_link


![Components](Add photo of your components here)
https://drive.google.com/drive/folders/1NgciboqRQ3D8SlPK08RZ5MxKaDJyoMJc?usp=drive_link


![Build](Add photos of build process here)
*Explain the build steps*

![Final](Add photo of final product here)
*Explain the final build*

### Project Demo
# Video
https://drive.google.com/drive/folders/1663csg4C76ArlhsMdDB-nzxFFgUvSpOC?usp=drive_link

# Additional Demos
[Add any extra demo materials/links]

## Team Contributions
- Glenys Gladson: Manual Mode UI and database,Integration
- Dharshana K S: ChatBot AI,Integration
- Christeena Geejo: Sign-in and Login and its database,Integration

---
Made with ❤️ at TinkerHub




>>>>>>> 320b99b51dc785f27f6149ce82422a7e834d8453
